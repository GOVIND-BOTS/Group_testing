# Telegram Group Manager Bot (No MongoDB)

## Features
- `/start` in private chat and groups with Owner, Add Me To Your Group, Group/Channel and Updates buttons.
- `/ban`, `/unban`, `/mute`, `/unmute`
- `/gban`, `/ungban`, `/gmute`, `/ungmute`
- `/help`, `/commands`, `/id`
- Uses local JSON file instead of MongoDB.

## Deploy to Render
Create a **Background Worker** connected to this GitHub repo.
Build command: `pip install -r requirements.txt`
Start command: `python bot.py`
Set environment variables listed in `.env.example`. No `MONGO_URI` is needed.

## VPS
`pip install -r requirements.txt`
Set environment variables, then `python bot.py`.

## Important storage note
Global ban/mute lists are stored in `moderation_data.json`. On Render/Heroku, local filesystem changes may be lost on restart/redeploy, depending on the host and configuration. For reliable permanent global lists, use a database or persistent disk. Ordinary group ban/mute actions are handled by Telegram and remain in effect until changed.

Add the bot as an admin in each group with Ban Users and Restrict Members permissions. Global actions only work in groups where the bot is present and has permissions. Replace sample button URLs with your real links.
